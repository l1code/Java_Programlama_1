/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.edu.isparta.baslangic;

/**
 *
 * @author drhal
 */
public class Uygulama1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Pazara giden sarı çizmeli ahmet ağa, 
        //pazarda aşağıda listelenmiş olan gıdaları almıştır. 
        //pazara gitmeden önce cebinde 200 tl'si varsa, pazar sonrasında ne kadarı kalmıştır. 
        //
        
        /***
         * pazar domates fiyatı  2kilo domates 10 lira,
         * 1 kilo muz 8 lira
         * 1 kilo mantar, 12 tl 
         * 1 kilo hamsi 25 tl 
         * 4 kilo portakal 8tl 
         */
        
        //+ toplama, - çıkarma, * çarpma anlamında kullanılmaktadır. 
        
        int domatesFiyati=5;
        int domatesKilo=2;        
        int domatesNetFiyati=domatesFiyati*domatesKilo;
        
        int muzFiyati=8;
        int muzKilo=1;
        int muzNetFiyati=muzFiyati*muzKilo;
        
        int mantarFiyati=12;
        int mantarKilo=1;
        int mantarNetFiyati=mantarFiyati*mantarKilo;
        
        int hamsiFiyati=25;
        int hamsiKilo=1;
        int hamsiNetFiyati=hamsiFiyati*hamsiKilo;
        
        int portakalFiyati=2;
        int portakalKilo=4;
        int portakalNetFiyati=portakalFiyati*portakalKilo;        
        
        int anaPara=200;
        int pazaraHarcananPara=domatesNetFiyati+muzNetFiyati+mantarNetFiyati+hamsiNetFiyati+portakalNetFiyati;
        int kalanPara=anaPara-(pazaraHarcananPara);        
           
        System.out.println("Kalan Para:"+kalanPara);
    }
    
}
