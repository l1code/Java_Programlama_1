/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.edu.isparta.temel;

/**
 *
 * @author drhal
 */
public class temelIslemler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //uzunluk 19 ise 0-18 arası 
        String degisken="teknik bilimler myo";
        String degisken1="teknik";
        String degisken2="bilimler";
        String degisken3="myo";
        
        
        char a=degisken.charAt(18);
        char b=degisken.charAt(17);
        char c=degisken.charAt(16);
        //....
        
        char z=degisken.charAt(0);
        int uzunluk=degisken.length();
        
        char[] gecici = new char[uzunluk];
        for (int i = 0; i <= uzunluk-1; i++) {
            gecici[i]=degisken.charAt(i);
        }
           
        for (int i = 0; i < gecici.length; i=i+8) {
            System.out.println(gecici[i]);
        }
        
        /*
        int sayac=0;
        while(sayac<uzunluk){
            //++sayac;
            System.out.println(gecici[sayac]);
            sayac=sayac+8;
            //sayac++;
            //++sayac;           
        }   
        */
    }
    
}
