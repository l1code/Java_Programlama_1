/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.edu.isparta.temel;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author drhal
 */
public class Siralama {
    public void sirala(int[] rastgele,int kosul){
         /*
         * 
         * rastgele integer bir dizidir.
         * bu dizi istediğimiz bir boyutta 
         * istediğimiz bir sınıra kadar rasgele 
         * sayılardan oluşmaktadır.
         */
         
         if(kosul==1){
             //buyukten kucuge siralama
             for (int i = 0; i < rastgele.length; i++) {
                 // tek bir değer için geriye kalan tüm sayılar 
                 // ile karşılaştırma yapmaktadır.
                 for (int j = 0; j < rastgele.length-1; j++) {
                     if(rastgele[j]<rastgele[j+1]){
                         int gecici=rastgele[j]; //kaybetme ihtimali
                         rastgele[j]=rastgele[j+1];
                         rastgele[j+1]=gecici;//takas
                     }
                 }
             }
             
             System.out.println("Sıralama sonucu:");
             for (int i = 0; i < rastgele.length; i++) {
                 System.out.println(rastgele[i]);
             }
         }else{
             //kucukten buyuge siralama
             for (int i = 0; i < rastgele.length; i++) {
                 // tek bir değer için geriye kalan tüm sayılar 
                 // ile karşılaştırma yapmaktadır.
                 for (int j = 0; j < rastgele.length-1; j++) {
                     if(rastgele[j]>rastgele[j+1]){
                         int gecici=rastgele[j];//kaybetme ihtimali
                         rastgele[j]=rastgele[j+1];
                         rastgele[j+1]=gecici;
                     }
                 }
             }
             
             System.out.println("Sıralama Sonucu:");
             for (int i = 0; i < rastgele.length; i++) {
                 System.out.println(rastgele[i]);
             }
         }
    }
    public int[] rastgeleSayiDizisiOlustur(int dizininBoyutu, int aralik){
         /*
         * istediğimiz boyutta olacak
         */
        /*
         * aralik değeri 0-aralik arasında 
         * sayı üretilmesini sağlayacak olam
         * parametredir.
         * 
         */
        
        Random nesne=new Random();
        int[] rastgeleDizi=new int[dizininBoyutu];
        int sayac=0;
        
        do{
        rastgeleDizi[sayac]=nesne.nextInt(aralik);
         /*
              * sayac diyorum ki diziniBoyutu aştıgı ise
              * donguyu sonlandırmak için kullanıyorum.
              * aralik mesala 1000e kadar sayı uret 
              */
         sayac=sayac+1;
        }while(sayac<dizininBoyutu);
        // bu işlemi while ve for ile yapıyorsunuz.
        
        sayac=0;
        while(sayac<dizininBoyutu){
            System.out.println(rastgeleDizi[sayac]);
            sayac++;
        }
        
        System.out.println("_____________________________");
        System.out.println("dizi tanımlandı");
        return rastgeleDizi;
    }
    public int[] konsoldanDiziDegerOkuma(){
        Scanner tara=new Scanner(System.in);
        System.out.println("Dizinin boyutunu giriniz:");
        int boyut=tara.nextInt();
        
        System.out.println("Rastgele sayılar kaç değerine kadar istiyorsunuz???");
        int aralik=tara.nextInt();
        
        System.out.println("Buyukten Kucuge Dogru Siralama için 1'e, "
                + "Tersi için 2'ye Basınız:");        
        int kosul=tara.nextInt();
        
        int[] geriDonduren=new int[3];
        geriDonduren[0]=boyut;
        geriDonduren[1]=aralik;
        geriDonduren[2]=kosul;      
        
        return geriDonduren;
    }
    
    public static void main(String[] args){
        Siralama nesne=new Siralama();
        int[] geriDonen=nesne.konsoldanDiziDegerOkuma();
        
        int[] rastgeleDizi=nesne.rastgeleSayiDizisiOlustur(geriDonen[0], geriDonen[1]);
        nesne.sirala(rastgeleDizi, geriDonen[2]);
    }
}
