/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.isparta.edu.Services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

/**
 *
 * @author drhal
 */
public class BolumService {
    public void BolumEkleme(Connection con){
        String query="insert into bolum(Adi, Aciklama, Eposta) ";
        query +="values('İnşaat. Müh.','İnşaat Mühendisliği','insaatmuh@isparta.edu.tr');";
        
        try{
            Statement stm=(Statement)con.createStatement();
            int executeUpdate=stm.executeUpdate(query);
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        System.out.println("Ekleme işlemi başarıyla tamamlandı.");
    }
    
    public void BolumEkleme(String adi, String aciklama, String eposta){
        String query="insert into bolum(Adi,Aciklama,Eposta) values(?,?,?) ";
        
        try{
            Connection con=new DBConnector().BaglantiGetir();
            Statement stm=(Statement)con.createStatement();
            PreparedStatement preparedStmt=con.prepareStatement(query);
            preparedStmt.setString(1, adi);
            preparedStmt.setString(2, aciklama);
            preparedStmt.setString(3, eposta);
            
            preparedStmt.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
    }
}
