/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tekrarlayansiralama;

import java.util.Random;
import java.util.Vector;

/**
 *
 * @author drhal
 */
public class TekrarlayanSiralama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Sınav Soru: 
        //a) 0-1500 aralığında 1000 adet integer tipinde rastgele sayı oluşturun.
        //b) oluşturulan bu sayıların içerinde;
        // Sadece kendisine ve 1 sayısına bölünebilen 1'den büyük pozitif tam sayılar olarak ifade edilen 
        //asal sayıları bulan azalanRecursiveAsal(int bolen, int sayi) adlı iki parametre içeren 
        //ilk parametresi bölen sayı, ikincisi kontrol edilen sayıyı ifade eden parametreleri alan 
        //asal sayı bulma fonksiyonunu yazınız. 
        //c) Bulunan asal sayıları ve asal olmayan sayıları yazdırınız. 
        Vector v=new TekrarlayanSiralama().rastgeleListe();
        /*for (int i = 0; i < v.size(); i++) {
            System.out.println(v.get(i));
        }*/
        
        /*int sayi=4;
        int bolen=2;
        
        if(sayi%bolen==0){
            System.out.println("bu sayı asal değildir");
        }else{
            System.out.println("bu sayı asaldır.");
        }*/
        v.clear();
        v.addElement(4);
        
        
        new TekrarlayanSiralama().AsalYazdirmaFonksiyonu(v);
        
    }
    
    //kendi kendini çağıran fonksiyona recursive fonksiyon denilmektedir.
    //burada asal sayıları buldurmaya çalışmaktayız.
    //asal sayılar; sadece iki pozitif tam sayı böleni olan doğal sayılardır. 
    // Sadece kendisine ve 1 sayısına bölünebilen 1'den büyük pozitif tam sayılardır.   
    // örneğin 2 sayısı asaldır. sadece kendisine ve 1 sayısına bölünebilmektedir. 
    //2/2==1 2/1==2 
    //örneğin 4 sayısı asal değildir. sebebi kendisine kadar olan sayıları bölmeye çalıştığımızda 
    //4 sayısının 4/1==4, 4/2==2, 4/4==1 
    //kendisi ve 1 'e bölünme dışında 2 sayısına da bölündüğü görülmektedir. 
    //4'ün 2 ile bölümünden kalan 0 olacağı için bu bölünme durumunun kontrol edilmesi gerekmektedir. 
    public int azalanRecursiveAsal(int bolen, int sayi){
        if(sayi==2){
            //asal sayı
            return 1;
        }
        if((sayi%bolen==0)&&(bolen>=2)){
            //asal değildir
            return 0;
        }else if((sayi%bolen!=0)&&(bolen>=2)){
            return azalanRecursiveAsal(bolen-1, sayi);
            //fonksiyonun kendi içerisinde kendisini çağırmasına recursive fonksiyon denilmektedir.
        }else{
            //asal sayı
            return 1;
        }
    }
    
    public Vector rastgeleListe(){
        Random nesne=new Random();
        int[] dizi=null;
        //Vektörler dinamik olarak üretilen sayıları tutabileceğimiz dinamik dizilerdir. 
        Vector v=new Vector();
        for (int i = 0; i < 1000; i++) {
            v.add(nesne.nextInt(1500));
        }        
        return v;        
    }  
    
    public void AsalYazdirmaFonksiyonu(Vector v){       
        
        for (Object v1 : v) {
            int baslangic=(Integer)v1;
            //boolean AsalMi;
            int bolen=2;
            if(baslangic<=2){
                baslangic=2;
            }
            
            //AsalMi=false;
            bolen=0;
            int sayi=baslangic;
            bolen=sayi-1;
            
            if(azalanRecursiveAsal(bolen, sayi)==1){
                System.out.println("Asal Sayı:"+sayi);
            }else{
                System.out.println("Asal Olmayan Sayı:"+sayi);
            }
        }
        
    }
}
