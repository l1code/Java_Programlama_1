/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.isparta.edu.Services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author drhal
 */
public class KitapYazarService {
    public void Ekleme(String adi, String soyadi,String TCKimlikNo){
        String query = "insert into kitapyazar(Ad, Soyad,TCKimlikNo) values(?,?,?) ";
        //INSERT INTO `kitapyazar`(`ID`, `Ad`, `Soyad`, `TCKimlikNo`) VALUES ([value-1],[value-2],[value-3],[value-4])
        
        
        try{
            Connection con=new DBConnector().BaglantiGetir();
            Statement stm = (Statement) con.createStatement();
            PreparedStatement preparedStmt=con.prepareStatement(query);
            
            preparedStmt.setString(1, adi);
            preparedStmt.setString(2, soyadi);
            preparedStmt.setString(3, TCKimlikNo);
            
            preparedStmt.execute();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }       
    }
    
    
    public DefaultTableModel Getir(DefaultTableModel model){
        model.getDataVector().removeAllElements();
        Statement stmt=null;   
        String sorgu="select ID, Ad, Soyad,TCKimlikNo from kitapyazar ";
        
        try{
            Connection con=new DBConnector().BaglantiGetir();
            stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(sorgu);
            
            while(rs.next()){
                int ID=rs.getInt(1);
                String adi=rs.getString(2);
                String soyadi=rs.getString(3);
                String TCKimlikNo=rs.getString(4);
                
                model.addRow(new Object[]{ID,adi,soyadi,TCKimlikNo});
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            try{
                if(stmt!=null){
                    stmt.close();
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
        
        return model;
    }
}
