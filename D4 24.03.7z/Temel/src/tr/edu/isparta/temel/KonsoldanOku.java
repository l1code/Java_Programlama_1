/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tr.edu.isparta.temel;

import java.util.InputMismatchException;
import java.util.Scanner;





/**
 *
 * @author drhal
 */
public class KonsoldanOku {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        KonsoldanOku konsoldanOkuNesne=new KonsoldanOku();
        konsoldanOkuNesne.Oku();
    }
    
    public void Oku(){
        Scanner sistemOku=new Scanner(System.in);
        System.out.println("Dizinin boyutunu giriniz:");
        int boyut=sistemOku.nextInt();
        System.out.println("Rasgele sayılarda aralik kaç istiyorsunuz:");
        int aralik=sistemOku.nextInt();
        
        System.out.println("Boyut:"+boyut);
        System.out.println("Aralık:"+aralik);
        
        
        System.out.println("noktalı sayı okuma için bir değer giriniz:");
        double girilenNoktaliDeger=sistemOku.nextDouble();
        System.out.println("Double Deger:"+girilenNoktaliDeger);
        
        System.out.println("Float noktalı sayılar için bir değer giriniz:");
        float girilenFloatDeger=sistemOku.nextFloat();
        System.out.println("Float Değer:"+girilenFloatDeger);
        
        try{
            System.out.println("en uzun araligi sahip long türü bir değer giriniz:");
            long longDeger=sistemOku.nextLong();
            System.out.println("Long Değer:"+longDeger);
        }catch(InputMismatchException e){
            System.out.println(e.getMessage());
        }
        
    }
    
    
    
}
